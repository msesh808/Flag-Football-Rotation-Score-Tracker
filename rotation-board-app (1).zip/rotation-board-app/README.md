# Flag Football Rotation Board

A small web app for coaches: enter a roster, mark positions, pick how players
rotate, and get even-playing-time lineups, a score tracker and a printable game sheet.
Everything is in this folder. There is nothing to build or install.

Game formats: 5v5 (up to 12 players), 6v6 (up to 14) and 7v7 (up to 16). Coaches pick
the format under Team setup, and the position lists switch to match.

A season holds up to 10 games. For each game a coach can mark players who are missing
(the main roster does not change), keep the score, and end the game to record the result.
The Season tab lists every week's score and result with a season tally at the bottom.

## Files

| File | What it is |
|---|---|
| `index.html` | The whole app |
| `manifest.webmanifest` | Name, colors and icons used when a coach installs it |
| `sw.js` | Lets the app open with no signal |
| `icon-192.png`, `icon-512.png` | Home-screen icons |

Keep all five files together in the same folder.

## Put it online (pick one)

The app needs a web address that starts with `https://`. Both options below are free.
The hosts change their screens from time to time, so the button names may differ a little.

### Option A: Netlify (easiest, no code tools)

1. Go to netlify.com and create a free account.
2. From your team page choose **Add new site**, then **Deploy manually**.
3. Drag this whole folder onto the upload box.
4. Netlify gives you an address like `something.netlify.app`. Rename it under
   **Site configuration** if you want a nicer one.

### Option B: GitHub Pages

1. Go to github.com, create a free account, then create a new **public** repository
   (for example `rotation-board`).
2. Choose **Add file > Upload files** and upload the five files from this folder
   (the files themselves, not the folder).
3. Open **Settings > Pages**. Under **Build and deployment**, set the source to
   **Deploy from a branch**, pick the `main` branch and the `/ (root)` folder, and save.
4. After a minute or two the page shows your address:
   `https://YOUR-USERNAME.github.io/rotation-board/`

## Share it with coaches

Send coaches the address. To install it like an app:

- **iPhone or iPad:** open the address in Safari, tap **Share**, then **Add to Home Screen**.
- **Android:** open it in Chrome, tap the menu, then **Install app** or **Add to Home screen**.
- **Computer:** in Chrome or Edge, use the install icon in the address bar.

After the first visit it opens with no signal.

## What coaches should know

- Each coach's team, lineups and scores are saved on their own device, in that browser.
  Nothing is sent anywhere.
- Clearing the browser's site data erases the team. **Team setup > Save a backup file**
  makes a file they can load on another device.
- Changing positions, players or rotation settings rebuilds the lineups and clears any
  spots changed by hand on the Game tab.

## Updating the app

Replace `index.html` (or any other file) on your host with the new version.
Coaches get the update the next time they open the app while online.
